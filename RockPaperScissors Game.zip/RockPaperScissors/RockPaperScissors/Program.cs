﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPSgame
{
    class RockPaperScissors
    {
        static void Main(string[] args)
        {
            ///random object that will allow the computer to choose at random
            Random random = new Random();

            //keeping score for the game, the first to 3 wins
            int playerScore = 0;
            int enemyScore = 0;

            //welcoming the user to our program
            Console.WriteLine("Are you ready to play! rock, paper scissors \n");

            //this will loop until the player or the enemy wins the game, the first to 3 wins
            while (playerScore != 3 && enemyScore != 3)
            {
                //will display the score to the user/player
                Console.WriteLine("PlayerScore - " + playerScore + "  EnemyScore - " + enemyScore);
                //prompting the user/player for an input
                Console.WriteLine("Please enter 'r' for rock, 'p' for paper, any for scissor: ");
                //reads the user/player input 
                string playerInput = Console.ReadLine();

                /*using the Random object for the enemy choice,
                 the enemy choice is set for only 3 choices*/
                int enemyChoice = random.Next(0, 3);

                if (enemyChoice == 0)
                {
                    Console.WriteLine("Enemy chooses rock.");
                    //using switch statements to compare enemy choice and user/player choice
                    switch (playerInput)
                    {
                        case "r":
                            Console.WriteLine("Tie");
                            break;
                        case "p":
                            Console.WriteLine("player wins round! ");
                            playerScore++;
                            break;
                        default:
                            Console.WriteLine("enemy wins round! ");
                            enemyScore++;
                            break;
                    }
                }
                else if (enemyChoice == 1)
                {
                    Console.WriteLine("Enemy Chooses Paper.");
                    switch (playerInput)
                    {
                        case "r":
                            Console.WriteLine("enemy wins round!");
                            enemyScore++;
                            break;
                        case "p":
                            Console.WriteLine("Tie");
                            break;
                        default:
                            Console.WriteLine("player wins round! ");
                            playerScore++;
                            break;
                    }
                }
                else 
                {
                    Console.WriteLine("Enemy chooses scissors. ");
                    switch (playerInput)
                    {
                        case "r":
                            Console.WriteLine("player wins round! ");
                            playerScore++;
                            break;
                        case "p":
                            Console.WriteLine("enemy wins round! ");
                            enemyScore++;
                            break;
                        default:
                            Console.WriteLine("Tie");
                            break;
                    }
                }
            }
            if (playerScore == 3)
            {
                //will compare scores and displays who won
                Console.WriteLine("You Win! \n");
            }
            else
            {
                Console.WriteLine("Enemy Wins \n");
            }



        }
    }
}


